﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Proyecto_Pokemon.Models;

namespace Proyecto_Pokemon.Controllers
{
    public class SolicitudesDeCuracionsController : Controller
    {
        private readonly JuegoPokemonContext _context;

        public SolicitudesDeCuracionsController(JuegoPokemonContext context)
        {
            _context = context;
        }

        // GET: SolicitudesDeCuracions
        public async Task<IActionResult> Index()
        {
            var juegoPokemonContext = _context.SolicitudesDeCuracions.Include(s => s.Entrenador).Include(s => s.Pokemon);
            return View(await juegoPokemonContext.ToListAsync());
        }

        // GET: SolicitudesDeCuracions/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var solicitudesDeCuracion = await _context.SolicitudesDeCuracions
                .Include(s => s.Entrenador)
                .Include(s => s.Pokemon)
                .FirstOrDefaultAsync(m => m.SolicitudCuracionId == id);
            if (solicitudesDeCuracion == null)
            {
                return NotFound();
            }

            return View(solicitudesDeCuracion);
        }

        // GET: SolicitudesDeCuracions/Create
        public IActionResult Create()
        {
            ViewData["EntrenadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId");
            ViewData["PokemonId"] = new SelectList(_context.Pokemons, "PokemonId", "PokemonId");
            return View();
        }

        // POST: SolicitudesDeCuracions/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SolicitudCuracionId,EntrenadorId,PokemonId,Estado,FechaSolicitud")] SolicitudesDeCuracion solicitudesDeCuracion)
        {
            if (ModelState.IsValid)
            {
                _context.Add(solicitudesDeCuracion);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["EntrenadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeCuracion.EntrenadorId);
            ViewData["PokemonId"] = new SelectList(_context.Pokemons, "PokemonId", "PokemonId", solicitudesDeCuracion.PokemonId);
            return View(solicitudesDeCuracion);
        }

        // GET: SolicitudesDeCuracions/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var solicitudesDeCuracion = await _context.SolicitudesDeCuracions.FindAsync(id);
            if (solicitudesDeCuracion == null)
            {
                return NotFound();
            }
            ViewData["EntrenadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeCuracion.EntrenadorId);
            ViewData["PokemonId"] = new SelectList(_context.Pokemons, "PokemonId", "PokemonId", solicitudesDeCuracion.PokemonId);
            return View(solicitudesDeCuracion);
        }

        // POST: SolicitudesDeCuracions/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SolicitudCuracionId,EntrenadorId,PokemonId,Estado,FechaSolicitud")] SolicitudesDeCuracion solicitudesDeCuracion)
        {
            if (id != solicitudesDeCuracion.SolicitudCuracionId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(solicitudesDeCuracion);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SolicitudesDeCuracionExists(solicitudesDeCuracion.SolicitudCuracionId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EntrenadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeCuracion.EntrenadorId);
            ViewData["PokemonId"] = new SelectList(_context.Pokemons, "PokemonId", "PokemonId", solicitudesDeCuracion.PokemonId);
            return View(solicitudesDeCuracion);
        }

        // GET: SolicitudesDeCuracions/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var solicitudesDeCuracion = await _context.SolicitudesDeCuracions
                .Include(s => s.Entrenador)
                .Include(s => s.Pokemon)
                .FirstOrDefaultAsync(m => m.SolicitudCuracionId == id);
            if (solicitudesDeCuracion == null)
            {
                return NotFound();
            }

            return View(solicitudesDeCuracion);
        }

        // POST: SolicitudesDeCuracions/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var solicitudesDeCuracion = await _context.SolicitudesDeCuracions.FindAsync(id);
            if (solicitudesDeCuracion != null)
            {
                _context.SolicitudesDeCuracions.Remove(solicitudesDeCuracion);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SolicitudesDeCuracionExists(int id)
        {
            return _context.SolicitudesDeCuracions.Any(e => e.SolicitudCuracionId == id);
        }
    }
}
