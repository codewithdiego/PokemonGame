﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Proyecto_Pokemon.Models;

namespace Proyecto_Pokemon.Controllers
{
    public class SolicitudesDeBatallasController : Controller
    {
        private readonly JuegoPokemonContext _context;

        public SolicitudesDeBatallasController(JuegoPokemonContext context)
        {
            _context = context;
        }

        // GET: SolicitudesDeBatallas
        public async Task<IActionResult> Index()
        {
            var juegoPokemonContext = _context.SolicitudesDeBatallas.Include(s => s.Oponente).Include(s => s.Retador);
            return View(await juegoPokemonContext.ToListAsync());
        }

        // GET: SolicitudesDeBatallas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var solicitudesDeBatalla = await _context.SolicitudesDeBatallas
                .Include(s => s.Oponente)
                .Include(s => s.Retador)
                .FirstOrDefaultAsync(m => m.SolicitudBatallaId == id);
            if (solicitudesDeBatalla == null)
            {
                return NotFound();
            }

            return View(solicitudesDeBatalla);
        }

        // GET: SolicitudesDeBatallas/Create
        public IActionResult Create()
        {
            ViewData["OponenteId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId");
            ViewData["RetadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId");
            return View();
        }

        // POST: SolicitudesDeBatallas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SolicitudBatallaId,RetadorId,OponenteId,Estado,FechaSolicitud")] SolicitudesDeBatalla solicitudesDeBatalla)
        {
            if (ModelState.IsValid)
            {
                _context.Add(solicitudesDeBatalla);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["OponenteId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeBatalla.OponenteId);
            ViewData["RetadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeBatalla.RetadorId);
            return View(solicitudesDeBatalla);
        }

        // GET: SolicitudesDeBatallas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var solicitudesDeBatalla = await _context.SolicitudesDeBatallas.FindAsync(id);
            if (solicitudesDeBatalla == null)
            {
                return NotFound();
            }
            ViewData["OponenteId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeBatalla.OponenteId);
            ViewData["RetadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeBatalla.RetadorId);
            return View(solicitudesDeBatalla);
        }

        // POST: SolicitudesDeBatallas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SolicitudBatallaId,RetadorId,OponenteId,Estado,FechaSolicitud")] SolicitudesDeBatalla solicitudesDeBatalla)
        {
            if (id != solicitudesDeBatalla.SolicitudBatallaId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(solicitudesDeBatalla);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SolicitudesDeBatallaExists(solicitudesDeBatalla.SolicitudBatallaId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["OponenteId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeBatalla.OponenteId);
            ViewData["RetadorId"] = new SelectList(_context.Usuarios, "UsuarioId", "UsuarioId", solicitudesDeBatalla.RetadorId);
            return View(solicitudesDeBatalla);
        }

        // GET: SolicitudesDeBatallas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var solicitudesDeBatalla = await _context.SolicitudesDeBatallas
                .Include(s => s.Oponente)
                .Include(s => s.Retador)
                .FirstOrDefaultAsync(m => m.SolicitudBatallaId == id);
            if (solicitudesDeBatalla == null)
            {
                return NotFound();
            }

            return View(solicitudesDeBatalla);
        }

        // POST: SolicitudesDeBatallas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var solicitudesDeBatalla = await _context.SolicitudesDeBatallas.FindAsync(id);
            if (solicitudesDeBatalla != null)
            {
                _context.SolicitudesDeBatallas.Remove(solicitudesDeBatalla);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SolicitudesDeBatallaExists(int id)
        {
            return _context.SolicitudesDeBatallas.Any(e => e.SolicitudBatallaId == id);
        }
    }
}
