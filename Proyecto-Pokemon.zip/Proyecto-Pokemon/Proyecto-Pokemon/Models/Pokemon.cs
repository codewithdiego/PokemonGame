﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class Pokemon
{
    public int PokemonId { get; set; }

    public int? EntrenadorId { get; set; }

    public string Nombre { get; set; } = null!;

    public int? TipoId { get; set; }

    public int? Nivel { get; set; }

    public int? Salud { get; set; }

    public virtual Usuario? Entrenador { get; set; }

    public virtual ICollection<SolicitudesDeCuracion> SolicitudesDeCuracions { get; set; } = new List<SolicitudesDeCuracion>();

    public virtual Tipo? Tipo { get; set; }
}
