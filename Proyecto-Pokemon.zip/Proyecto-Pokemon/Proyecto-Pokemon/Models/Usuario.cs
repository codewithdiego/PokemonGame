﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class Usuario
{
    public int UsuarioId { get; set; }

    public string NombreUsuario { get; set; } = null!;

    public string HashContrasena { get; set; } = null!;

    public int? RolId { get; set; }

    public string? NombreEntrenador { get; set; }

    public virtual ICollection<Mensaje> MensajeDestinatarios { get; set; } = new List<Mensaje>();

    public virtual ICollection<Mensaje> MensajeRemitentes { get; set; } = new List<Mensaje>();

    public virtual ICollection<Pokemon> Pokemons { get; set; } = new List<Pokemon>();

    public virtual Role? Rol { get; set; }

    public virtual ICollection<SolicitudesDeBatalla> SolicitudesDeBatallaOponentes { get; set; } = new List<SolicitudesDeBatalla>();

    public virtual ICollection<SolicitudesDeBatalla> SolicitudesDeBatallaRetadors { get; set; } = new List<SolicitudesDeBatalla>();

    public virtual ICollection<SolicitudesDeCuracion> SolicitudesDeCuracions { get; set; } = new List<SolicitudesDeCuracion>();
}
