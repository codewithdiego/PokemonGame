﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class SolicitudesDeCuracion
{
    public int SolicitudCuracionId { get; set; }

    public int? EntrenadorId { get; set; }

    public int? PokemonId { get; set; }

    public string? Estado { get; set; }

    public DateTime? FechaSolicitud { get; set; }

    public virtual Usuario? Entrenador { get; set; }

    public virtual Pokemon? Pokemon { get; set; }
}
