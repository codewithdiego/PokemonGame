﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class SolicitudesDeBatalla
{
    public int SolicitudBatallaId { get; set; }

    public int? RetadorId { get; set; }

    public int? OponenteId { get; set; }

    public string? Estado { get; set; }

    public DateTime? FechaSolicitud { get; set; }

    public virtual Usuario? Oponente { get; set; }

    public virtual Usuario? Retador { get; set; }
}
