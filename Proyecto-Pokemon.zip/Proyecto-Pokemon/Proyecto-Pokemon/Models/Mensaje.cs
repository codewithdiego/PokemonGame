﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class Mensaje
{
    public int MensajeId { get; set; }

    public int? RemitenteId { get; set; }

    public int? DestinatarioId { get; set; }

    public string Contenido { get; set; } = null!;

    public DateTime? FechaHora { get; set; }

    public virtual Usuario? Destinatario { get; set; }

    public virtual Usuario? Remitente { get; set; }
}
