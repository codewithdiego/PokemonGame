﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class Tipo
{
    public int TipoId { get; set; }

    public string NombreTipo { get; set; } = null!;

    public virtual ICollection<Pokedex> Pokedices { get; set; } = new List<Pokedex>();

    public virtual ICollection<Pokemon> Pokemons { get; set; } = new List<Pokemon>();
}
