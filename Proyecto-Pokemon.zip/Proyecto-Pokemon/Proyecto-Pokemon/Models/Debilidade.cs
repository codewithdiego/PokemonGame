﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class Debilidade
{
    public int DebilidadId { get; set; }

    public string NombreDebilidad { get; set; } = null!;

    public virtual ICollection<Pokedex> Pokedices { get; set; } = new List<Pokedex>();
}
