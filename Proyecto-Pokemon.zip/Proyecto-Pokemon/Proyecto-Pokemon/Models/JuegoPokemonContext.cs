﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Proyecto_Pokemon.Models;

public partial class JuegoPokemonContext : DbContext
{
    public JuegoPokemonContext()
    {
    }

    public JuegoPokemonContext(DbContextOptions<JuegoPokemonContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Debilidade> Debilidades { get; set; }

    public virtual DbSet<Mensaje> Mensajes { get; set; }

    public virtual DbSet<Pokedex> Pokedices { get; set; }

    public virtual DbSet<Pokemon> Pokemons { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<SolicitudesDeBatalla> SolicitudesDeBatallas { get; set; }

    public virtual DbSet<SolicitudesDeCuracion> SolicitudesDeCuracions { get; set; }

    public virtual DbSet<Tipo> Tipos { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("server=localhost; database=JuegoPokemon; integrated security=true; TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Debilidade>(entity =>
        {
            entity.HasKey(e => e.DebilidadId).HasName("PK__Debilida__D57A2F793B9EC7FA");

            entity.HasIndex(e => e.NombreDebilidad, "UQ__Debilida__5317C55B49F58C15").IsUnique();

            entity.Property(e => e.NombreDebilidad).HasMaxLength(50);
        });

        modelBuilder.Entity<Mensaje>(entity =>
        {
            entity.HasKey(e => e.MensajeId).HasName("PK__Mensajes__FEA0555FE0DEB7EC");

            entity.Property(e => e.Contenido).HasMaxLength(500);
            entity.Property(e => e.FechaHora)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Destinatario).WithMany(p => p.MensajeDestinatarios)
                .HasForeignKey(d => d.DestinatarioId)
                .HasConstraintName("FK__Mensajes__Destin__534D60F1");

            entity.HasOne(d => d.Remitente).WithMany(p => p.MensajeRemitentes)
                .HasForeignKey(d => d.RemitenteId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Mensajes__Remite__52593CB8");
        });

        modelBuilder.Entity<Pokedex>(entity =>
        {
            entity.HasKey(e => e.PokedexId).HasName("PK__Pokedex__F1E7C41BA38A5E56");

            entity.ToTable("Pokedex");

            entity.HasIndex(e => e.Numero, "UQ__Pokedex__7E532BC60ED9F189").IsUnique();

            entity.Property(e => e.Evoluciones).HasMaxLength(255);
            entity.Property(e => e.Nombre).HasMaxLength(50);
            entity.Property(e => e.Peso).HasColumnType("decimal(5, 2)");

            entity.HasOne(d => d.Tipo).WithMany(p => p.Pokedices)
                .HasForeignKey(d => d.TipoId)
                .HasConstraintName("FK__Pokedex__TipoId__44FF419A");

            entity.HasMany(d => d.Debilidads).WithMany(p => p.Pokedices)
                .UsingEntity<Dictionary<string, object>>(
                    "PokedexDebilidade",
                    r => r.HasOne<Debilidade>().WithMany()
                        .HasForeignKey("DebilidadId")
                        .HasConstraintName("FK__PokedexDe__Debil__48CFD27E"),
                    l => l.HasOne<Pokedex>().WithMany()
                        .HasForeignKey("PokedexId")
                        .HasConstraintName("FK__PokedexDe__Poked__47DBAE45"),
                    j =>
                    {
                        j.HasKey("PokedexId", "DebilidadId").HasName("PK__PokedexD__7CB066EC8999F770");
                        j.ToTable("PokedexDebilidades");
                    });
        });

        modelBuilder.Entity<Pokemon>(entity =>
        {
            entity.HasKey(e => e.PokemonId).HasName("PK__Pokemons__69C4E9233DFB66E1");

            entity.Property(e => e.Nombre).HasMaxLength(50);
            entity.Property(e => e.Salud).HasDefaultValue(100);

            entity.HasOne(d => d.Entrenador).WithMany(p => p.Pokemons)
                .HasForeignKey(d => d.EntrenadorId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Pokemons__Entren__4BAC3F29");

            entity.HasOne(d => d.Tipo).WithMany(p => p.Pokemons)
                .HasForeignKey(d => d.TipoId)
                .HasConstraintName("FK__Pokemons__TipoId__4CA06362");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RolId).HasName("PK__Roles__F92302F17B0140FE");

            entity.HasIndex(e => e.NombreRol, "UQ__Roles__4F0B537F4F15A647").IsUnique();

            entity.Property(e => e.NombreRol).HasMaxLength(20);
        });

        modelBuilder.Entity<SolicitudesDeBatalla>(entity =>
        {
            entity.HasKey(e => e.SolicitudBatallaId).HasName("PK__Solicitu__D1AE3EB6C8BF3429");

            entity.ToTable("SolicitudesDeBatalla");

            entity.Property(e => e.Estado).HasMaxLength(20);
            entity.Property(e => e.FechaSolicitud)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Oponente).WithMany(p => p.SolicitudesDeBatallaOponentes)
                .HasForeignKey(d => d.OponenteId)
                .HasConstraintName("FK__Solicitud__Opone__5812160E");

            entity.HasOne(d => d.Retador).WithMany(p => p.SolicitudesDeBatallaRetadors)
                .HasForeignKey(d => d.RetadorId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Solicitud__Retad__571DF1D5");
        });

        modelBuilder.Entity<SolicitudesDeCuracion>(entity =>
        {
            entity.HasKey(e => e.SolicitudCuracionId).HasName("PK__Solicitu__5118E9A48A9BEC61");

            entity.ToTable("SolicitudesDeCuracion");

            entity.Property(e => e.Estado).HasMaxLength(20);
            entity.Property(e => e.FechaSolicitud)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Entrenador).WithMany(p => p.SolicitudesDeCuracions)
                .HasForeignKey(d => d.EntrenadorId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Solicitud__Entre__5CD6CB2B");

            entity.HasOne(d => d.Pokemon).WithMany(p => p.SolicitudesDeCuracions)
                .HasForeignKey(d => d.PokemonId)
                .HasConstraintName("FK__Solicitud__Pokem__5DCAEF64");
        });

        modelBuilder.Entity<Tipo>(entity =>
        {
            entity.HasKey(e => e.TipoId).HasName("PK__Tipos__97099EB7A47C276C");

            entity.HasIndex(e => e.NombreTipo, "UQ__Tipos__7586661C61646310").IsUnique();

            entity.Property(e => e.NombreTipo).HasMaxLength(50);
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.UsuarioId).HasName("PK__Usuarios__2B3DE7B8E0E4701A");

            entity.HasIndex(e => e.NombreUsuario, "UQ__Usuarios__6B0F5AE0EDBBFF7B").IsUnique();

            entity.Property(e => e.HashContrasena).HasMaxLength(255);
            entity.Property(e => e.NombreEntrenador).HasMaxLength(50);
            entity.Property(e => e.NombreUsuario).HasMaxLength(50);

            entity.HasOne(d => d.Rol).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.RolId)
                .HasConstraintName("FK__Usuarios__RolId__3B75D760");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
