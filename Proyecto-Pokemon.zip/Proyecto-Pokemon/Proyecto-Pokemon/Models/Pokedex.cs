﻿using System;
using System.Collections.Generic;

namespace Proyecto_Pokemon.Models;

public partial class Pokedex
{
    public int PokedexId { get; set; }

    public string Nombre { get; set; } = null!;

    public int? TipoId { get; set; }

    public string? Evoluciones { get; set; }

    public decimal? Peso { get; set; }

    public int Numero { get; set; }

    public virtual Tipo? Tipo { get; set; }

    public virtual ICollection<Debilidade> Debilidads { get; set; } = new List<Debilidade>();
}
